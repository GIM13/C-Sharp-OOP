﻿namespace MXGP.Repositories
{
    public class MotorcycleRepository<Motorcycle> 
        : Repository<Motorcycle>
    {
    }
}

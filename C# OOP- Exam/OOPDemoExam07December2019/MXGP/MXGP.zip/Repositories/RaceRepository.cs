﻿namespace MXGP.Repositories
{
    public class RaceRepository<Race> 
        : Repository<Race> 
    {
    }
}

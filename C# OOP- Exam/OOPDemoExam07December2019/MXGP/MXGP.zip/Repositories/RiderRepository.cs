﻿namespace MXGP.Repositories
{
    public class RiderRepository<Rider> 
        : Repository<Rider> 
    {
    }
}

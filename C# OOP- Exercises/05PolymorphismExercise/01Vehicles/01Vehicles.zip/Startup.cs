﻿namespace _01Vehicles
{
    class Startup
    {
        static void Main()
        {
            Engine.Start();
        }
    }
}

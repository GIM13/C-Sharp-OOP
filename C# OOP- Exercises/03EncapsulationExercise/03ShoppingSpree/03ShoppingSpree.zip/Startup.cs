﻿namespace _03ShoppingSpree
{
    class Startup
    {
        static void Main()
        {
            Engine.Start();
        }
    }
}

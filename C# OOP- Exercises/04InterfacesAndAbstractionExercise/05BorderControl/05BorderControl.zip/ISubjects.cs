﻿namespace _05BorderControl
{
    public interface ISubjects
    {
        public long Id { get; } 
    }
}
